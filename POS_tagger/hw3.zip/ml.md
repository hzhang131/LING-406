# Machine Learning Practice
## The zip file contains:
1. POS_encoder.ipynb: The POS encoding implementation of Naive Bayes/ Decision Tree Algorithm.
2. LabelEncoder.ipynb: The Label encoding implementation of Naive Bayes/ Decision Tree Algorithm
3. Report.pdf: Report for this assignment. 
## Have a great day! 
    